import {
  users,
  clients,
  projects,
  tasks,
  goals,
  revenues,
  attachments,
  activityLogs,
  type User,
  type UpsertUser,
  type Client,
  type InsertClient,
  type Project,
  type InsertProject,
  type Task,
  type InsertTask,
  type Goal,
  type InsertGoal,
  type Revenue,
  type InsertRevenue,
  type Attachment,
  type InsertAttachment,
  type ActivityLog,
  type InsertActivityLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  updateUserRole(id: string, role: string): Promise<User | undefined>;

  // Client operations
  getClients(): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<boolean>;

  // Project operations
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByClient(clientId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Task operations
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  getTasksByUser(userId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;

  // Goal operations
  getGoals(year?: number): Promise<Goal[]>;
  getGoal(id: number): Promise<Goal | undefined>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: number, goal: Partial<InsertGoal>): Promise<Goal | undefined>;
  deleteGoal(id: number): Promise<boolean>;

  // Revenue operations
  getRevenues(): Promise<Revenue[]>;
  createRevenue(revenue: InsertRevenue): Promise<Revenue>;

  // Activity log operations
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getActivityLogs(limit?: number): Promise<ActivityLog[]>;

  // Dashboard stats
  getDashboardStats(): Promise<any>;
  getReportData(months: number): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users).where(eq(users.isActive, true));
  }

  async updateUserRole(id: string, role: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role: role as any, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Client operations
  async getClients(): Promise<Client[]> {
    return db.select().from(clients).orderBy(desc(clients.createdAt));
  }

  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async createClient(client: InsertClient): Promise<Client> {
    const [newClient] = await db.insert(clients).values(client).returning();
    return newClient;
  }

  async updateClient(id: number, client: Partial<InsertClient>): Promise<Client | undefined> {
    const [updated] = await db
      .update(clients)
      .set({ ...client, updatedAt: new Date() })
      .where(eq(clients.id, id))
      .returning();
    return updated;
  }

  async deleteClient(id: number): Promise<boolean> {
    const result = await db.delete(clients).where(eq(clients.id, id));
    return true;
  }

  // Project operations
  async getProjects(): Promise<Project[]> {
    return db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getProjectsByClient(clientId: number): Promise<Project[]> {
    return db.select().from(projects).where(eq(projects.clientId, clientId));
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined> {
    const [updated] = await db
      .update(projects)
      .set({ ...project, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updated;
  }

  async deleteProject(id: number): Promise<boolean> {
    await db.delete(projects).where(eq(projects.id, id));
    return true;
  }

  // Task operations
  async getTasks(): Promise<Task[]> {
    return db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getTasksByUser(userId: string): Promise<Task[]> {
    return db
      .select()
      .from(tasks)
      .where(eq(tasks.assignedToId, userId))
      .orderBy(desc(tasks.createdAt));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined> {
    const [updated] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return updated;
  }

  async deleteTask(id: number): Promise<boolean> {
    await db.delete(tasks).where(eq(tasks.id, id));
    return true;
  }

  // Goal operations
  async getGoals(year?: number): Promise<Goal[]> {
    if (year) {
      return db.select().from(goals).where(eq(goals.year, year)).orderBy(goals.month);
    }
    return db.select().from(goals).orderBy(desc(goals.year), goals.month);
  }

  async getGoal(id: number): Promise<Goal | undefined> {
    const [goal] = await db.select().from(goals).where(eq(goals.id, id));
    return goal;
  }

  async createGoal(goal: InsertGoal): Promise<Goal> {
    const [newGoal] = await db.insert(goals).values(goal).returning();
    return newGoal;
  }

  async updateGoal(id: number, goal: Partial<InsertGoal>): Promise<Goal | undefined> {
    const [updated] = await db
      .update(goals)
      .set({ ...goal, updatedAt: new Date() })
      .where(eq(goals.id, id))
      .returning();
    return updated;
  }

  async deleteGoal(id: number): Promise<boolean> {
    await db.delete(goals).where(eq(goals.id, id));
    return true;
  }

  // Revenue operations
  async getRevenues(): Promise<Revenue[]> {
    return db.select().from(revenues).orderBy(desc(revenues.receivedAt));
  }

  async createRevenue(revenue: InsertRevenue): Promise<Revenue> {
    const [newRevenue] = await db.insert(revenues).values(revenue).returning();
    return newRevenue;
  }

  // Activity log operations
  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [newLog] = await db.insert(activityLogs).values(log).returning();
    return newLog;
  }

  async getActivityLogs(limit = 50): Promise<ActivityLog[]> {
    return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit);
  }

  // Dashboard stats
  async getDashboardStats(): Promise<any> {
    const [clientCount] = await db
      .select({ count: count() })
      .from(clients)
      .where(eq(clients.isActive, true));

    const [activeProjectCount] = await db
      .select({ count: count() })
      .from(projects)
      .where(
        and(
          sql`${projects.status} != 'concluido'`,
          sql`${projects.status} != 'cancelado'`
        )
      );

    const [pendingTaskCount] = await db
      .select({ count: count() })
      .from(tasks)
      .where(
        and(
          sql`${tasks.status} != 'concluida'`,
          sql`${tasks.status} != 'cancelada'`
        )
      );

    const [revenueSum] = await db
      .select({ total: sql<string>`COALESCE(SUM(${revenues.amount}), 0)` })
      .from(revenues);

    const recentProjectsResult = await db
      .select()
      .from(projects)
      .orderBy(desc(projects.createdAt))
      .limit(5);

    const recentTasksResult = await db
      .select()
      .from(tasks)
      .where(
        and(
          sql`${tasks.status} != 'concluida'`,
          sql`${tasks.status} != 'cancelada'`
        )
      )
      .orderBy(desc(tasks.createdAt))
      .limit(5);

    // Get monthly revenue for the last 6 months
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyRevenue = await db
      .select({
        month: sql<string>`TO_CHAR(${revenues.receivedAt}, 'YYYY-MM')`,
        revenue: sql<number>`COALESCE(SUM(${revenues.amount}), 0)`,
      })
      .from(revenues)
      .where(gte(revenues.receivedAt, sixMonthsAgo))
      .groupBy(sql`TO_CHAR(${revenues.receivedAt}, 'YYYY-MM')`)
      .orderBy(sql`TO_CHAR(${revenues.receivedAt}, 'YYYY-MM')`);

    // Projects by type
    const projectsByType = await db
      .select({
        type: projects.type,
        count: count(),
      })
      .from(projects)
      .groupBy(projects.type);

    // Projects by status
    const projectsByStatus = await db
      .select({
        status: projects.status,
        count: count(),
      })
      .from(projects)
      .groupBy(projects.status);

    return {
      totalClients: clientCount?.count || 0,
      activeProjects: activeProjectCount?.count || 0,
      pendingTasks: pendingTaskCount?.count || 0,
      totalRevenue: parseFloat(revenueSum?.total || "0"),
      recentProjects: recentProjectsResult,
      recentTasks: recentTasksResult,
      monthlyRevenue: monthlyRevenue.map((r) => ({
        month: r.month,
        revenue: parseFloat(r.revenue?.toString() || "0"),
      })),
      projectsByType: projectsByType.map((p) => ({
        type: p.type,
        count: p.count,
      })),
      projectsByStatus: projectsByStatus.map((p) => ({
        status: p.status,
        count: p.count,
      })),
    };
  }

  // Report data
  async getReportData(months: number): Promise<any> {
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - months);

    const previousStartDate = new Date(startDate);
    previousStartDate.setMonth(previousStartDate.getMonth() - months);

    // Current period revenue
    const [currentRevenue] = await db
      .select({ total: sql<string>`COALESCE(SUM(${revenues.amount}), 0)` })
      .from(revenues)
      .where(gte(revenues.receivedAt, startDate));

    // Previous period revenue
    const [previousRevenue] = await db
      .select({ total: sql<string>`COALESCE(SUM(${revenues.amount}), 0)` })
      .from(revenues)
      .where(
        and(gte(revenues.receivedAt, previousStartDate), lte(revenues.receivedAt, startDate))
      );

    // Total and completed projects
    const [projectStats] = await db
      .select({
        total: count(),
        completed: sql<number>`COUNT(*) FILTER (WHERE ${projects.status} = 'concluido')`,
      })
      .from(projects)
      .where(gte(projects.createdAt, startDate));

    // Total and new clients
    const [clientStats] = await db.select({ total: count() }).from(clients);
    
    const [newClients] = await db
      .select({ count: count() })
      .from(clients)
      .where(gte(clients.createdAt, startDate));

    // Revenue by month
    const revenueByMonth = await db
      .select({
        month: sql<string>`TO_CHAR(${revenues.receivedAt}, 'YYYY-MM')`,
        revenue: sql<number>`COALESCE(SUM(${revenues.amount}), 0)`,
      })
      .from(revenues)
      .where(gte(revenues.receivedAt, startDate))
      .groupBy(sql`TO_CHAR(${revenues.receivedAt}, 'YYYY-MM')`)
      .orderBy(sql`TO_CHAR(${revenues.receivedAt}, 'YYYY-MM')`);

    // Revenue by project type
    const revenueByType = await db
      .select({
        type: projects.type,
        revenue: sql<number>`COALESCE(SUM(${projects.value}), 0)`,
      })
      .from(projects)
      .where(
        and(
          gte(projects.createdAt, startDate),
          eq(projects.status, "concluido")
        )
      )
      .groupBy(projects.type);

    // Projects by month
    const projectsByMonth = await db
      .select({
        month: sql<string>`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`,
        count: count(),
      })
      .from(projects)
      .where(gte(projects.createdAt, startDate))
      .groupBy(sql`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`)
      .orderBy(sql`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`);

    // Top clients by revenue
    const topClients = await db
      .select({
        name: clients.name,
        revenue: sql<number>`COALESCE(SUM(${projects.value}), 0)`,
        projects: count(),
      })
      .from(clients)
      .leftJoin(projects, eq(clients.id, projects.clientId))
      .groupBy(clients.id, clients.name)
      .orderBy(sql`COALESCE(SUM(${projects.value}), 0) DESC`)
      .limit(10);

    return {
      totalRevenue: parseFloat(currentRevenue?.total || "0"),
      previousRevenue: parseFloat(previousRevenue?.total || "0"),
      totalProjects: projectStats?.total || 0,
      completedProjects: projectStats?.completed || 0,
      totalClients: clientStats?.total || 0,
      newClients: newClients?.count || 0,
      revenueByMonth: revenueByMonth.map((r) => ({
        month: r.month,
        revenue: parseFloat(r.revenue?.toString() || "0"),
      })),
      revenueByType: revenueByType.map((r) => ({
        type: r.type,
        revenue: parseFloat(r.revenue?.toString() || "0"),
      })),
      projectsByMonth: projectsByMonth.map((p) => ({
        month: p.month,
        count: p.count,
      })),
      topClients: topClients.map((c) => ({
        name: c.name,
        revenue: parseFloat(c.revenue?.toString() || "0"),
        projects: c.projects,
      })),
    };
  }
}

export const storage = new DatabaseStorage();
